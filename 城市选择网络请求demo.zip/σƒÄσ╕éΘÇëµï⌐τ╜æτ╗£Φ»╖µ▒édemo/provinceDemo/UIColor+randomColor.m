//
//  UIColor+randomColor.m
//  10-20饼图练习
//
//  Created by ma c on 15/10/20.
//  Copyright (c) 2015年 cn.itcast. All rights reserved.
//

#import "UIColor+randomColor.h"

@implementation UIColor (randomColor)

//随机取的颜色
+ (UIColor *)randomColor {
    CGFloat a = arc4random_uniform(256) / 255.0;
    CGFloat b = arc4random_uniform(256) / 255.0;
    CGFloat c = arc4random_uniform(256) / 255.0;
    return [UIColor colorWithRed:a green:b blue:c alpha:1.0];
}

@end
