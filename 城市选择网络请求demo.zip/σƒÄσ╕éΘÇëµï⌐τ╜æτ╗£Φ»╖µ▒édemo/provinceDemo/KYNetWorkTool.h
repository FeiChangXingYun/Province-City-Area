//
//  KYNetWorkTool.h
//  KY
//
//  Created by mac on 15/11/27.
//  Copyright © 2015年 zhouxubin. All rights reserved.
//

#import "AFHTTPSessionManager.h"

@interface KYNetWorkTool : AFHTTPSessionManager

+ (instancetype)sharedNetWorkTool;

@end
