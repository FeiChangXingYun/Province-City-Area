//
//  ViewController.m
//  provinceDemo
//
//  Created by 周旭斌 on 16/4/27.
//  Copyright © 2016年 周旭斌. All rights reserved.
//

#import "ViewController.h"
#import "MJExtension.h"
#import "XBProvinceObj.h"
#import "XBHeaderView.h"
#import "KYNetWorkTool.h"
#import "SVProgressHUD.h"
#import "XBArea.h"

@interface ViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) UITableView *tableView;

/**
 *  数据源(省)
 */
@property (nonatomic, strong) NSArray *provinceArray;

/**
 *  市
 */
@property (nonatomic, strong) NSMutableArray *citiesArray;
/**
 *  记录点击的组
 */
@property (nonatomic, assign) NSUInteger index;
/**
 *  是否展开
 */
@property (nonatomic, assign, getter=isSpread) BOOL spread;
@property (nonatomic, strong) NSMutableArray *tempArray;
/**
 *  cell是否展开
 */
@property (nonatomic, assign, getter=isCellSpread) BOOL cellSpread;
/**
 *  记录点击的市
 */
@property (nonatomic, strong) XBCityObj *cityObj;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    NSArray *array = [NSArray arrayWithObjects:@"wendy",@"andy",@"tom",@"test", nil];
    
    //使用block 块遍历整个数组。这个block 需要三个参数，id obj 表示数组中的元素。NSUInteger idx 标示元素的下标，bool *stop 是一个bool类型的参数
//    [array enumerateObjectsUsingBlock:^(id str,NSUInteger index, BOOL* te){
//        NSLog(@"%@,%ld",str,index);
//    }];
    
    //同上面的方法一项，区别在于，这里多添加了一个参数，用来标示 是从前向后遍历，还是从后往前遍历
//    [array enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id str,NSUInteger index, BOOL* te){
//        NSLog(@"%@,%ld",str,index);
//    }];
    
    //同上面的方法一项，不过NSIndexSet 参数标示，根据下标取出的数组，这里真正在block 中遍历的数组，是根据NSindexSet 取到的子数组
//    [array enumerateObjectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(1, 3)] options:NSEnumerationReverse usingBlock:^(id str,NSUInteger index, BOOL* te){
//        NSLog(@"%@,%ld",str,index);
//    }];
    
    [self tableView];
}

#pragma mark - tableView datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.provinceArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    XBProvinceObj *provinceObj = _provinceArray[section];
    if (provinceObj.isSpread) {
        return provinceObj.cities.count;
    }else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *ID = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    
    XBProvinceObj *provinceObj = _provinceArray[indexPath.section];
    NSObject *obj = provinceObj.cities[indexPath.row];
    if ([obj isKindOfClass:[XBCityObj class]]) {
#warning 这里是市的设置
        XBCityObj *cityObj = (XBCityObj *)obj;
        cell.textLabel.text = cityObj.name;
        cell.detailTextLabel.text = nil;
    }else {
#warning 这里是区的设置
        XBArea *area = (XBArea *)obj;
        cell.textLabel.text = nil;
        cell.detailTextLabel.text = area.name;
    }
    
    return cell;
}

#pragma mark - tableView delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
   
    XBProvinceObj *provinceObj = _provinceArray[indexPath.section];
    NSObject *obj = provinceObj.cities[indexPath.row];
    
    if (![obj isKindOfClass:[XBCityObj class]]) {
#warning 这里可以做点击具体区需要执行的代码...
        XBArea *area = (XBArea *)obj;
        NSLog(@"%@", area.name);
        return;
    }
    
    NSMutableArray *tempArray = [NSMutableArray array];
    XBCityObj *cityObj = (XBCityObj *)obj;
    [[KYNetWorkTool sharedNetWorkTool] POST:@"http://123.56.82.112/gupiao/index.php/Api/Apiuser/getarea/pid/53" parameters:@{@"pid" : cityObj.ID} success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
        
        for (int i = 0; i < [responseObject[@"data"] count]; ++i) {
            NSIndexPath *indexP = [NSIndexPath indexPathForRow:indexPath.row + 1 + i inSection:indexPath.section];
            [tempArray addObject:indexP];
        }
        
        if (cityObj.isSpread) {
            // cell已经展开,应该删除
            for (XBCityObj *obj in cityObj.sub) {
                [provinceObj.cities removeObject:obj];
            }
            [tableView deleteRowsAtIndexPaths:tempArray withRowAnimation:UITableViewRowAnimationFade];
            self.cellSpread = NO;
            cityObj.spread = NO;
        }else {
            // cell没展开,应该添加
            cityObj.sub = [XBArea mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
            for (int i = 0; i < [responseObject[@"data"] count]; ++i) {
                [provinceObj.cities insertObject:cityObj.sub[i] atIndex:indexPath.row + 1 + i];
            }
            [tableView insertRowsAtIndexPaths:tempArray withRowAnimation:UITableViewRowAnimationFade];
            self.cellSpread = YES;
            cityObj.spread = YES;
        }
        
        [tableView reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationFade];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD showErrorWithStatus:@"网络繁忙,请稍后再试!"];
    }];
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    XBProvinceObj *provinceObj = _provinceArray[section];
    XBHeaderView *headerView = [XBHeaderView headerViewWith:tableView];
    headerView.tag = section;
    headerView.provinceObj = provinceObj;
    __weak typeof(self) Self = self;
    //假如clickBlock调用
    headerView.clickBlock = ^(NSUInteger index) {
        if (provinceObj.isSpread) {
            //需要展开
            [[KYNetWorkTool sharedNetWorkTool] POST:@"http://123.56.82.112/gupiao/index.php/Api/Apiuser/getarea/pid/53" parameters:@{@"pid" : provinceObj.ID} success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
                [provinceObj.cities addObjectsFromArray:[XBCityObj mj_objectArrayWithKeyValuesArray:responseObject[@"data"]]];
                //刷新指定的区
                [Self.tableView reloadSections:[NSIndexSet indexSetWithIndex:index] withRowAnimation:UITableViewRowAnimationFade];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [SVProgressHUD showErrorWithStatus:@"网络繁忙,请稍后再试!"];
            }];
        }else {
            //假如没有闭合，就移除数组中所有对象
            [provinceObj.cities removeAllObjects];
            [Self.tableView reloadSections:[NSIndexSet indexSetWithIndex:index] withRowAnimation:UITableViewRowAnimationFade];
        }
    };
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 44;
}

#pragma mark - 懒加载
- (UITableView *)tableView {
    if (!_tableView) {
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
        tableView.delegate = self;
        tableView.dataSource = self;
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}

- (NSArray *)provinceArray {
    if (!_provinceArray) {
        [[KYNetWorkTool sharedNetWorkTool] POST:@"http://123.56.82.112/gupiao/index.php/Api/Apiuser/getarea/pid/53" parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
            //字典数组->模型数组,放的是XBProvinceObj对象
            _provinceArray = [XBProvinceObj mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
            [self.tableView reloadData];
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [SVProgressHUD showErrorWithStatus:@"网络繁忙,请稍后再试!"];
        }];
    }
    return _provinceArray;
}

- (NSMutableArray *)citiesArray {
    if (!_citiesArray) {
        _citiesArray = [NSMutableArray array];
    }
    return _citiesArray;
}

@end
