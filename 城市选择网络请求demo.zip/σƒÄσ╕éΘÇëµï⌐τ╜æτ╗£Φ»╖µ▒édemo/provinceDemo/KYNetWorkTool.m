//
//  KYNetWorkTool.m
//  KY
//
//  Created by mac on 15/11/27.
//  Copyright © 2015年 zhouxubin. All rights reserved.
//

#define BASEURL @"http://c.m.163.com/nc/"
#import "KYNetWorkTool.h"

@implementation KYNetWorkTool

static KYNetWorkTool *_instance;
+ (instancetype)sharedNetWorkTool {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        _instance = [[self alloc] initWithBaseURL:[NSURL URLWithString:BASEURL]];
        _instance.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/plain",@"text/html", nil];
        
        //设置请求时间,间隔
        [_instance.requestSerializer willChangeValueForKey:@"timeoutInterval"];
        _instance.requestSerializer.timeoutInterval = 15.0;
        [_instance.requestSerializer didChangeValueForKey:@"timeoutInterval"];

    });
    return _instance;
}

@end
