//
//  XBProvinceObj.h
//  provinceDemo
//
//  Created by 周旭斌 on 16/4/27.
//  Copyright © 2016年 周旭斌. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XBCityObj.h"

@interface XBProvinceObj : NSObject

/**
 *  id
 */
@property (nonatomic, copy) NSString *ID;
/**
 *  省的名字
 */
@property (nonatomic, copy) NSString *name;
/**
 *  pid
 */
@property (nonatomic, copy) NSString *pid;
/**
 *  省,市,区 (1,2,3)
 */
@property (nonatomic, copy) NSString *type;
/**
 *  市模型数组(XBCityObj)
 */
@property (nonatomic, strong) NSArray *sub;
/**
 *  是否展开
 */
@property (nonatomic, assign, getter=isSpread) BOOL spread;
/**
 *  用来装所有的市
 */
@property (nonatomic, strong) NSMutableArray *cities;
/*id = 2;
	name = 北京;
	pid = 1;
	type = 1;*/

@end
