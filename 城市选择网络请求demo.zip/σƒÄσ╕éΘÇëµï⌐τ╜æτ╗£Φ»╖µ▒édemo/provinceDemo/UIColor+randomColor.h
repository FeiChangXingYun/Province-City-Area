//
//  UIColor+randomColor.h
//  10-20饼图练习
//
//  Created by ma c on 15/10/20.
//  Copyright (c) 2015年 cn.itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (randomColor)

+ (UIColor *)randomColor;

@end
