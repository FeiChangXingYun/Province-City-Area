//
//  XBArea.m
//  provinceDemo
//
//  Created by 周旭斌 on 16/5/11.
//  Copyright © 2016年 周旭斌. All rights reserved.
//

#import "XBArea.h"
#import "MJExtension.h"

@implementation XBArea

//将属性名换为其他key去字典中取值
//@return 字典中的key是属性名，value是从字典中取值用的key
//比如后台返回的json数据中有一个key是我在xcode中是关键字,我需要换成其他的一个名字,就通过这个方法告诉框架这个名字就对应那个key
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID" : @"id"};
}

@end
