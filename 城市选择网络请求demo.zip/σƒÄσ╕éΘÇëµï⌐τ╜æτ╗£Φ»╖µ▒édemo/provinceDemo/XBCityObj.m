//
//  XBCityObj.m
//  provinceDemo
//
//  Created by 周旭斌 on 16/4/27.
//  Copyright © 2016年 周旭斌. All rights reserved.
//

#import "XBCityObj.h"
#import "MJExtension.h"

@implementation XBCityObj

//将属性名换为其他key去字典中取值
//@return 字典中的key是属性名，value是从字典中取值用的key
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID" : @"id"};
}

@end
