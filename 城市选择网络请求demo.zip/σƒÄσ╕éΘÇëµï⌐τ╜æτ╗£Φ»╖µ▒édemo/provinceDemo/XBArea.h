//
//  XBArea.h
//  provinceDemo
//
//  Created by 周旭斌 on 16/5/11.
//  Copyright © 2016年 周旭斌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XBArea : NSObject

/**
 *  唯一标示
 */
@property (nonatomic, copy) NSString *ID;
/**
 *  市的名字
 */
@property (nonatomic, copy) NSString *name;
/**
 *  pid
 */
@property (nonatomic, copy) NSString *pid;
/**
 *  省,市,区 (1,2,3)
 */
@property (nonatomic, copy) NSString *type;

@end
